<html>
<!-- <script src="https://jspreadsheet.com/v9/jspreadsheet.js"></script> -->
<!-- <script src="https://jsuites.net/v4/jsuites.js"></script> -->
<!-- <link rel="stylesheet" href="https://jspreadsheet.com/v9/jspreadsheet.css" type="text/css" /> -->
<!-- <link rel="stylesheet" href="https://jsuites.net/v4/jsuites.css" type="text/css" /> -->
<!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Material+Icons" /> -->

<!-- <script src="https://cdn.jsdelivr.net/npm/jszip@3.6.0/dist/jszip.min.js"></script> -->
<script src="https://cdn.jsdelivr.net/npm/@jspreadsheet/parser/dist/index.min.js"></script>


<script src="https://jspreadsheet.com/v9/jspreadsheet.js"></script>
<script src="https://jsuites.net/v4/jsuites.js"></script>
<link rel="stylesheet" href="https://jspreadsheet.com/v9/jspreadsheet.css" type="text/css" />
<link rel="stylesheet" href="https://jsuites.net/v4/jsuites.css" type="text/css" />
 
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Material+Icons" />
 
<script src="https://cdn.jsdelivr.net/npm/jszip@3.6.0/dist/jszip.min.js"></script>
<script src="https://jspreadsheet.com/v9/plugins/parser.js"></script>
<script src="https://jspreadsheet.com/v9/plugins/render.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('index')); ?>">
        <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
        <input type="file" name="file" id='file' onchange="load(event)" style='display:none'>
        <input type='button' value='Load a XLSX file from my local computer' onclick="document.getElementById('file').click()">
        <input type='button' value='Export to XLSX' onclick="download()">
        <button type="submit" class="btn btn-primary">Upload</button>
    </form>

<div id="spreadsheet"></div>

<script>
    // Set license

    const J_KEY = "<?php echo e(env('JSPAREADSHEET_KEY')); ?>";

    jspreadsheet.setLicense(J_KEY);

    // Set extensions
    jspreadsheet.setExtensions({ parser });

    // Create the spreadsheet from a local file
    var load = function(e) {
        // Parse XLSX file and create a new spreadsheet
        jspreadsheet.parser({
            file: e.target.files[0],
            // It would be used to updated the formats only
            locale: 'it-IT',
            onload: function(config) {
                jspreadsheet(document.getElementById('spreadsheet'), config);
            },
            onerror: function(error) {
                alert(error);
            }
        });
    }


    
 
// Import a XLSX file from a remote file
jspreadsheet.parser({
    url: '/jspreadsheet/list.xlsx',
    onload: function(config) {
        jspreadsheet(document.getElementById('spreadsheet'), config);
    },
});
 
    jspreadsheet.setExtensions({ parser, render });

    // Download method
    var download = function() {
    // Render to XLSX
    jspreadsheet.render(document.getElementById('spreadsheet'), {
        filename: 'export.xlsx',
    });
    }
</script>

</html><?php /**PATH C:\laragon\www\newtest\resources\views/data.blade.php ENDPATH**/ ?>