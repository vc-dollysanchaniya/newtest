<!DOCTYPE html>
<html>
    <head>
    <script src="{{ asset('jquery.js') }}"></script>

     <link href="{{ asset('jquery-ui.css') }}" rel="stylesheet" />
     <link href="{{ asset('jquery-ui.structure.css') }}" rel="stylesheet" />
     <link href="{{ asset('jquery-ui.theme.css') }}" rel="stylesheet" />
     <script src="{{ asset('jquery-ui.js') }}"></script>
    <link rel="stylesheet" href="{{ asset('bootstrap.min.css') }}" />


        <link rel='stylesheet' href="{{ asset('js/spectrum.css') }} " />

        <link rel="Stylesheet" href="{{ asset('js/pqSelect/pqselect.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('js/pqgrid.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('js/pqgrid.ui.min.css') }}" id="pqgrid_ui_link" />
        <link rel="stylesheet" href="{{ asset('js/pqgrid.css') }}" id="pqgrid_office_link" />
        <style>
            .pq-grid-cell {
                cursor: cell;
            }
        </style>
    </head>
    <body>
        <div id="spreadsheet" style="margin: auto;"></div>

        <script src="{{ asset('js/spectrum.js') }}"></script>
        <script src="{{ asset('js/jszip-2.5.0/jszip.min.js') }}"></script>
        <script src="{{ asset('js/pqgrid.min.js') }}"></script>
        <script src="{{ asset('js/localize/pq-localize-en.js') }}"></script>
        <script src="{{ asset('utils/farma.js') }}"></script>

        <!-- <script src="{{ asset('js/jquery.resize.js') }}" defer></script> -->
        <!-- <script src="{{ asset('js/pqTouch/pqtouch.min.js') }}"></script> -->
        <!-- <script src="{{ asset('js/pqselect.min.js') }}"></script> -->
        <!-- <script src="{{ asset('js/javascript-detect-element-resize/jquery.resize.js') }}" defer></script> -->

        <script type="text/javascript">
            var pq;
            $(function () {
                var grid = pq.grid("#spreadsheet", {
                    height: 930,
                    autoAddRow: true,
                    autoAddCol: true,
                    flex: {all: false},
                    showTitle: false,
                    numberCell: {width: 60},
                    sortModel: { on: false },
                    stripeRows: false,
                    filterModel: { hideRows: true },
                    menuIcon: true,
                    wrap: false,
                    collapsible: {on: false},
                    columnTemplate: {
                        filter: {
                            crules: [{condition: 'range'}]
                        },
                        title: function (ui) {
                            return pq.toLetter(ui.colIndx);
                        }
                    },
                    contextMenu: {
                        on: true,
                        imgItems: [
                            {
                                name: 'Delete',
                                action: function (evt, ui) {
                                    var Pic = this.Pic()
                                    Pic.remove( Pic.getId( ui.ele ) )
                                }
                            }
                        ],
                        cellItems: [
                            {
                                name: 'Border',
                                subItems: [
                                    {
                                        name: 'All Selection edges',
                                        action: function () {
                                            var grid = this,
                                                color = $(".border", grid.toolbar()).spectrum('option', 'color');
                                            grid.Selection().address().forEach(function (addr) {
                                                var r1 = addr.r1, c1 = addr.c1, r2 = addr.r2, c2 = addr.c2,
                                                    obj = {
                                                        left: grid.Range({ r1: r1, r2: r2, c1: c1, c2: c1 }),
                                                        top: grid.Range({ r1: r1, r2: r1, c1: c1, c2: c2 }),
                                                        right: grid.Range({ r1: r1, r2: r2, c1: c2, c2: c2 }),
                                                        bottom: grid.Range({ r1: r2, r2: r2, c1: c1, c2: c2 })
                                                    };

                                                for (var key in obj) {
                                                    obj[key].toggleStyle("border-" + key, ["1px solid " + color, ""])
                                                }
                                            });
                                        }
                                    },
                                    'separator',
                                    {
                                        name: 'Top',
                                        action: function () {
                                            var color = $(".border", this.toolbar()).spectrum('option', 'color')
                                            this.Selection().toggleStyle("border-top", ["1px solid " + color, ""])
                                        }
                                    },
                                    {
                                        name: 'Right',
                                        action: function () {
                                            var color = $(".border", this.toolbar()).spectrum('option', 'color')
                                            this.Selection().toggleStyle("border-right", ["1px solid " + color, ""])
                                        }
                                    },
                                    {
                                        name: 'Bottom',
                                        action: function () {
                                            var color = $(".border", this.toolbar()).spectrum('option', 'color')
                                            this.Selection().toggleStyle("border-bottom", ["1px solid " + color, ""])
                                        }
                                    },
                                    {
                                        name: 'Left',
                                        action: function () {
                                            var color = $(".border", this.toolbar()).spectrum('option', 'color')
                                            this.Selection().toggleStyle("border-left", ["1px solid " + color, ""])
                                        }
                                    },
                                    {
                                        name: 'All',
                                        action: function () {
                                            var color = $(".border", this.toolbar()).spectrum('option', 'color')
                                            this.Selection().toggleStyle("border", ["1px solid " + color, ""])
                                        }
                                    }
                                ]
                            },
                            'separator',
                            {
                                name: 'Insert column',
                                action: function (evt, ui) {
                                    var self = this,
                                        col = ui.column,
                                        parent = col.parent,
                                        CM = parent ? parent.colModel : self.option('colModel'),
                                        ci = CM.indexOf(col);

                                    self.Columns().add([{
                                        width: 100,
                                        dataIndx: Math.random(),
                                        halign: 'center'
                                    }], ci)
                                }
                            },
                            {
                                name: 'Delete column',
                                icon: 'ui-icon ui-icon-trash',
                                action: function (evt, ui) {
                                    var self = this,
                                        col = ui.column,
                                        CM = col.parent ? col.parent.colModel : self.option('colModel'),
                                        ci = CM.indexOf(col);

                                    self.Columns().remove(1, ci)
                                }
                            },
                            'separator',
                            {
                                name: 'Insert row',
                                action: function (evt, ui, item) {
                                    this.addNodes([{}], ui.rowIndx);
                                }
                            },
                            {
                                name: 'Insert 20 rows',
                                action: function (evt, ui) {
                                    this.addNodes(Array.apply(null, Array(20)).map(function () { return {} }), ui.rowIndx);
                                }
                            },
                            {
                                name: 'Delete row',
                                icon: 'ui-icon ui-icon-trash',
                                action: function (evt, ui) {
                                    this.deleteRow({
                                        rowIndx: ui.rowIndx
                                    })
                                }
                            },
                            'separator',
                            {
                                name: 'Merge',
                                action: function () {
                                    this.Selection().merge();
                                }
                            },
                            {
                                name: 'Un Merge',
                                action: function () {
                                    this.Selection().unmerge();
                                }
                            }
                        ]
                    },
                    toolbar: {
                        cls: 'pq-toolbar-export',
                        items: [
                            {
                                type: 'file',
                                attr: 'title="Open xlsx"',
                                attrFile: "accept='.xlsx,.csv'",
                                icon: 'ui-icon-folder-open',
                                style: 'margin-right:0;margin-left:1px;',
                                listener: function( evt ){
                                    //import xlsx or csv file via HTML5 file input control.
                                    var grid = this,
                                        file = evt.target.files[0];//doesn't work in IE9.

                                    if(file){
                                        grid.showLoading();
                                        //import first sheet of xlsx into workbook.
                                        pq.excel.importXl( {file: file, sheets: [0]}, function( wb ){

                                            //import workbook into grid.
                                            grid.importWb({workbook: wb, extraRows: 10, extraCols: 10});
                                            grid.hideLoading();
                                        })
                                    }
                                }
                            },
                            {
                                type: 'button',
                                options: { text: false, showLabel: false },
                                style: 'margin-right:0;margin-left:1px;',
                                attr: "title='Download'",
                                icon: 'ui-icon-arrowthickstop-1-s',
                                listener: function() {
                                    var blob = this.exportExcel({ render: true, noheader: true });
                                    saveAs(blob, "{{ asset('Jspreadsheetup/loadexcel/pqGrid.xlsx') }}");
                                }
                            },
                            {
                                type: 'file',
                                icon: 'ui-icon-image',
                                attr: "title='Add image'",
                                style: 'margin-right:0;margin-left:1px;',
                                attrFile: 'accept=".jpg,.jpeg,.png,.gif"',
                                listener: function (evt) {
                                    var files = evt.target.files;//doesn't work in IE9.
                                    if (files[0]) {
                                        this.Selection().pic(files[0], 5, 5);
                                    }
                                }
                            },
                            { type: 'separator' },
                            {
                                type: 'button',
                                attr: 'title="Bold"',
                                cls: 'bold',
                                label: "<b>B</b>",
                                style: 'margin-right:0',
                                listener: function (evt) {
                                    this.Selection().toggleStyle("font-weight", ["bold", "normal"]);
                                }
                            },
                            {
                                type: 'button',
                                attr: 'title="Italic"',
                                cls: 'italic',
                                label: "<i>I</i>",
                                style: 'margin:0',
                                listener: function (evt) {
                                    this.Selection().toggleStyle("font-style", ["italic", "normal"]);
                                }
                            },
                            {
                                type: 'button',
                                attr: 'title="Underline"',
                                cls: 'underline',
                                label: "<u>U</u>",
                                style: 'margin-left:0',
                                listener: function (evt) {
                                    this.Selection().toggleStyle("text-decoration", ["underline", "normal"]);
                                }
                            },
                            {
                                type: 'button',
                                attr: 'title="Wrap"',
                                cls: 'wrap',
                                label: "Wrap",
                                style: 'margin-left:0',
                                listener: function (evt) {
                                    this.Selection().toggleStyle("white-space", ["normal", "nowrap"]);
                                }
                            },
                            {
                                type: 'select',
                                attr: 'title="font size"',
                                cls: 'font-size',
                                options: [9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36],
                                listener: function (evt) {
                                    this.Selection().style('font-size', $(evt.target).val() + "px");
                                }
                            },
                            {
                                type: 'select',
                                attr: 'title="font family"',
                                cls: 'font-family',
                                options: ['Arial', 'Calibri', 'Caveat', 'Georgia', 'Impact', 'Verdana'],
                                listener: function (evt) {
                                    this.Selection().style('font-family', $(evt.target).val());
                                }
                            },
                            {
                                type: 'select',
                                attr: 'title="horizontal align"',
                                cls: 'align',
                                options: ['left', 'center', 'right'],
                                listener: function (evt) {
                                    this.Selection().align($(evt.target).val());
                                }
                            },
                            {
                                type: 'select',
                                attr: 'title="vertical align"',
                                cls: 'valign',
                                options: [{ 'top': 'top', 'center': 'middle', 'bottom': 'bottom' }],
                                listener: function (evt) {
                                    this.Selection().valign($(evt.target).val());
                                }
                            },
                            {
                                type: 'textarea',
                                attr: 'rows=2 placeholder="Add comment"',
                                cls: 'comment',
                                listener: function (evt) {
                                    this.Selection().comment($(evt.target).val());
                                }
                            },
                            {
                                type: 'button',
                                cls: 'enable',
                                label: 'Disable',
                                listener: function (evt) {
                                    this.Selection().enable(!this.Selection().enable());
                                }
                            },
                            { type: 'separator' },
                            {
                                type: 'button',
                                attr: 'title="Undo"',
                                icon: 'ui-icon-arrowreturn-1-s',
                                options: { text: false, showLabel: false, disabled: true },
                                cls: 'undo',
                                listener: function () {
                                    this.history({ method: 'undo' });
                                }
                            },
                            {
                                type: 'button',
                                attr: 'title="Redo"',
                                cls: 'redo',
                                icon: 'ui-icon-arrowrefresh-1-s',
                                options: { text: false, showLabel: false, disabled: true },
                                listener: function () {
                                    this.history({ method: 'redo' });
                                }
                            },
                            { type: 'separator' },
                            {
                                type: 'textbox',
                                cls: 'bgColor',
                                label: 'Bg: ',
                                attr: 'title="Background color"',
                                init: function (ele) {
                                    var S = this.Selection();
                                    $(ele).find('input').spectrum({
                                        color: "#ffffff",
                                        showPalette: true,
                                        change: function (color) {
                                            S.style('background-color', color.toHexString())
                                        }
                                    });
                                }
                            },
                            {
                                type: 'textbox',
                                cls: 'fgColor',
                                label: 'Fg: ',
                                attr: 'title="Text color"',
                                init: function ( ele ) {
                                    var S = this.Selection();
                                    $(ele).find('input').spectrum({
                                        color: "#000000",
                                        showPalette: true,
                                        change: function (color) {
                                            S.style('color', color.toHexString())
                                        }
                                    });
                                }
                            },
                            {
                                type: 'textbox',
                                cls: 'border',
                                label: 'Border: ',
                                init: function ( ele ) {

                                    $(ele).find('.border').spectrum({
                                        color: "#000000",
                                        showPalette: true,
                                        change: function (color) {
                                            $(this).spectrum('option', 'color', color.toHexString())
                                        }
                                    });
                                }
                            }
                        ]
                    },
                    history: function (evt, ui) {
                        var $tb = this.toolbar(),
                            $undo = $tb.find(".undo"),
                            $redo = $tb.find(".redo");

                        if (ui.canUndo != null) {
                            $undo.button("option", { disabled: !ui.canUndo });
                        }
                        if (ui.canRedo != null) {
                            $redo.button("option", "disabled", !ui.canRedo);
                        }
                        //$undo.button("option", { label: 'u (' + ui.num_undo + ')' });
                        //$redo.button("option", { label: 'r (' + ui.num_redo + ')' });
                    },
                    autoRow: true,
                    editModel: {
                        addDisableCls: true,
                        onSave: 'downFocus'
                    },
                    complete: function () {
                        this.on('selectEnd history', function () {

                            var S = this.Selection(), tb = this.toolbar();

                            $(".font-size", tb).val(parseInt(S.style('font-size')));
                            $(".font-family", tb).val(S.style('font-family'));

                            $(".valign", tb).val(S.valign());
                            $(".align").val(S.align());

                            $(".fgColor", tb).spectrum("set", S.style('color'))
                            $(".bgColor", tb).spectrum("set", S.style('background-color'))

                            $(".comment", tb).val(S.comment());

                            $(".enable", tb).button("option", "label", (S.enable() ? 'Disable' : 'Enable'))
                            $('.bold', tb).css({
                                borderColor: (S.style('font-weight') == 'bold' ? 'steelblue' : '')
                            })
                            $('.italic', tb).css({
                                borderColor: (S.style('font-style') == 'italic' ? 'steelblue' : '')
                            })
                            $('.underline', tb).css({
                                borderColor: (S.style('text-decoration') == 'underline' ? 'steelblue' : '')
                            })
                            $('.wrap', tb).css({
                                borderColor: (S.style('white-space') == 'normal' ? 'steelblue' : '')
                            })
                        })
                    }
                });

                

                // grid.showLoading();
                // //import xlsx file from remote location.
                // pq.excel.importXl( {url: '{{ asset("Jspreadsheet/uploadexcel/cube report.xlsx") }}'}, function( wb ){
                //     grid.importWb({ workbook: wb, extraRows: 10, extraCols: 10 });
                //     grid.hideLoading();
                // })

                })
        </script>
    </body>
</html>