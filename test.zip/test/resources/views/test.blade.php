<html>
<!-- <script src="https://bossanova.uk/jspreadsheet/v4/jexcel.js"></script>
<link rel="stylesheet" href="https://bossanova.uk/jspreadsheet/v4/jexcel.css" type="text/css" />
<script src="https://jsuites.net/v4/jsuites.js"></script>
<link rel="stylesheet" href="https://jsuites.net/v4/jsuites.css" type="text/css" />

<div id="spreadsheet"></div> -->
<body>
<!-- <a href="{{asset('Jspreadsheet/test.xlsx')}}" target="_blank">open myexcel.xls</a> -->
<script>

// jspreadsheet(document.getElementById('spreadsheet'), {
//     csv:'{{asset("Jspreadsheet/report/report1.csv")}}',
//     // csvHeaders:true,
//     // tableOverflow:true,
// });
var strFilePath =  '{{asset("Jspreadsheet/test.xlsx")}}';
function openExcelFile(strFilePath) {
   
            var objExcel;
            objExcel = new ActiveXObject("Excel.Application");
            objExcel.Visible = true;
            objExcel.Workbooks.Open(strLocation, false, true);
     
    
    }
// var request = new XMLHttpRequest();
// request.open("GET", "{{asset('Jspreadsheet/test.xlsx')}}");
// request.responseType = "blob";
// request.onload = function() {
//   // set `blob` `type` to `"text/html"`
//   var blob = new Blob([this.response], {type:"text/html"});
//   var url = URL.createObjectURL(blob);
//   var w = window.open(url);
// }
// request.send();

</script>
</body>
</html>


