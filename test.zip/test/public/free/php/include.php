<!DOCTYPE html>
<html lang="en">
	<head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>PQGrid with PHP</title>

<link rel="stylesheet" href="../../jquery-ui-1.9.0.custom/development-bundle/themes/base/jquery.ui.all.css" />		
<script src="../../jquery-ui-1.9.0.custom/js/jquery-1.8.2.js" ></script>        
<script src="../../jquery-ui-1.9.0.custom/js/jquery-ui-1.9.0.custom.js" ></script>

<!--link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/themes/base/jquery-ui.css" />    
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script-->

<link rel="stylesheet" href="../Content/css/pqgrid.min.css" >    

<script src="../Content/js/pqgrid.min.js"></script>
