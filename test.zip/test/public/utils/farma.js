(function (m) {
    var t,
        n = m.paramquery,
        e = {
            options: {
                stateColKeys: { width: 1, filter: ["crules", "mode"], hidden: 1 },
                stateKeys: { height: 1, width: 1, freezeRows: 1, freezeCols: 1, groupModel: ["dataIndx", "collapsed", "grandSummary"], pageModel: ["curPage", "rPP"], sortModel: ["sorter"] },
                detailModel: { cache: !0, offset: 100, expandIcon: _a(97), collapseIcon: _a(98), height: "auto" },
                dragColumns: { enabled: !0, acceptIcon: _a(99), rejectIcon: _a(100), topIcon: _a(101), bottomIcon: _a(102) },
                flex: { on: !0, one: !1, all: !0 },
                track: null,
                mergeModel: { flex: !1 },
                realFocus: !0,
                sortModel: { on: !0, type: "local", multiKey: "shiftKey", number: !0, single: !0, cancel: !0, sorter: [], useCache: !0, ignoreCase: !1 },
                filterModel: { on: !0, newDI: [], type: "local", mode: "AND", header: !1, timeout: 400 },
            },
            _create: function () {
                var t = this,
                    e = t.options;
                null == e.rtl && (e.rtl = "rtl" == t.element.css("direction")),
                    (t.listeners = {}),
                    (t[_b(153)] = {}),
                    (t.iHistory = new n.cHistory(t)),
                    (t.iGroup = new n.cGroup(t)),
                    (t.iMerge = new n.cMerge(t)),
                    (t[_b(159)] = new n[_b(307)](t)),
                    (t.iSelection = new pq.Selection(t)),
                    (t.iUCData = new n.cUCData(t)),
                    (t[_b(308)] = new n[_b(309)](t)),
                    t._super(),
                    new n.cFormula(t),
                    (t[_b(247)] = new n[_b(260)](t)),
                    t[_b(292)](),
                    "remote" === e.dataModel.location && t.refresh(),
                    t.on("dataAvailable", function () {
                        t.one("refreshDone", function () {
                            t._trigger("ready"),
                                setTimeout(function () {
                                    t.element && t._trigger("complete");
                                }, 0);
                        });
                    }),
                    t.__init(),
                    t[_b(118)]({ header: !0 });
            },
            __init: function () {
                t = t || m([_a(103), _a(104), "</div>"].join("")).appendTo(document.body);
            },
        },
        e =
            (m.widget("paramquery.pqGrid", n._pqGrid, e),
            (m.widget.extend = function () {
                var t,
                    e,
                    n,
                    i,
                    r,
                    o = Array.prototype.shift,
                    a = m[_b(43)],
                    l = m.isArray,
                    s = m.widget.extend,
                    d = o.apply(arguments),
                    c = ("boolean" == typeof d && ((t = d), (d = o.apply(arguments))), arguments),
                    u = 0,
                    h = c.length;
                for (null == t && (t = 1 < h); u < h; u++)
                    for (i in (e = c[u]))
                        ((r = (n = Object[_b(44)](e, i)).get) && "reactiveGetter" != r.name) || n.set
                            ? Object[_b(45)](d, i, n)
                            : void 0 !== (r = e[i]) && ((n = !(0 < u)), a(r) ? (r.byRef ? (d[i] = r) : ((d[i] = d[i] || {}), s(n, d[i], r))) : l(r) ? (d[i] = t && n ? r.slice() : r) : (d[i] = r));
                return d;
            }),
            (pq.grid = function (t, e) {
                t = m(t).pqGrid(e);
                return t.data("paramqueryPqGrid") || t.data("paramquery-pqGrid");
            }),
            (n.pqGrid.regional = {}),
            n.pqGrid.prototype);
    function p(t, e, n) {
        for (var i = 0, r = t.length; i < r; i++) {
            for (var o, a = t[i], l = {}, s = 0, d = e.length; s < d; s++) l[(o = e[s])] = a[o];
            n.push(l);
        }
    }
    (n.pqGrid.defaults = e.options),
        (e.focusT = function (t) {
            var e = this;
            setTimeout(function () {
                e.focus(t);
            });
        }),
        (e.focus = function (t) {
            var e,
                n,
                i,
                r,
                o,
                a = this,
                l = a._fe,
                t = t || l || {},
                s = !t.nofocus,
                d = a.options.editModel,
                c = t[_b(75)],
                t = t.colIndx,
                u = a.pdata,
                c = c >= u.length ? u.length - 1 : c,
                u = a.colModel,
                t = t > u.length ? u.length - 1 : t,
                u = a.iMerge,
                h = c + a.riOffset,
                t = -1 == t ? a[_b(175)](!0) : t;
            null != c &&
                null != t &&
                (u[_b(195)](h, t) && ((c = (u = u[_b(137)](h, t))[_b(75)]), (t = u.colIndx)),
                (h = a.iRenderB),
                (u = "ontouchstart" in window ? "disabled" : ""),
                (e = (r = h[_b(310)](c, t))[0]),
                (o = r[1]),
                (n = r[2]),
                (r = { left: e, top: o, height: r[3] - o - 2, width: n - e - 2 }),
                (o = h[_b(168)](c, t)[0]),
                l ? (l.$td && l.$td[_b(72)]("pq-focus"), (i = l.$ele) && i.parent()[0] != o && (l.$ele.remove(), (i = null))) : (l = a._fe = {}),
                (i = i || (l.$ele = m("<textarea " + u + _a(105)))).appendTo(o),
                i.val("").css(r),
                (l[_b(75)] = c),
                (l.colIndx = t),
                (l.$td = a.getCell(l)).addClass("pq-focus"),
                a.one("assignTblDims", function () {
                    i.css({ left: 0, top: 0 });
                }),
                s &&
                    (a.one("scroll", function () {
                        (l.$td = a.getCell(l)).addClass("pq-focus");
                    }),
                    i.blur(),
                    i[0].focus()),
                d[_b(229)] &&
                    i.off("input").on("input", function (t) {
                        var e = a.getEditor(l, "type"),
                            n = "select" == e;
                        a.isEditable(l) && e && !n && (a.editCell(l), (e = a[_b(66)]().$editor), (n = m(t.target).val()), e && e.val(n));
                    }),
                i.css({ height: 2, width: 2 }));
        }),
        (e.onfocus = function (t) {}),
        (e[_b(94)] = function () {}),
        (e.onblur = function () {}),
        (e.callFn = function (t, e) {
            return pq.getFn(t).call(this, e);
        }),
        (e.rowExpand = function (t) {
            this.iHierarchy.rowExpand(t);
        }),
        (e[_b(311)] = function (t) {
            this.iHierarchy[_b(311)](t);
        }),
        (e[_b(312)] = function (t) {
            this.iHierarchy[_b(312)](t);
        }),
        (e._saveState = function (t, e, n) {
            var i, r, o, a;
            for (i in n)
                (r = n[i]) &&
                    ((o = t[i]),
                    m.isArray(r)
                        ? null != o &&
                          ((a = e[i] = m[_b(43)](e[i]) ? e[i] : {}),
                          r.forEach(function (t) {
                              a[t] = o[t];
                          }))
                        : (e[i] = o));
        }),
        (e.saveState = function (t) {
            t = t || {};
            for (var e, n, i, r = this, o = r.element, a = r.options, l = a[_b(313)], s = a.stateKeys, d = r.colModel, c = [], u = 0, h = d.length, o = o[0].id; u < h; u++)
                (e = (n = d[u]).dataIndx), r._saveState(n, (n = { dataIndx: e }), l), (c[u] = n);
            return (
                (i = { colModel: c, datestamp: Date.now() }),
                r._saveState(a, i, s),
                (a = t.extra) && (i = m.extend(!0, i, a)),
                !1 !== t.stringify && ((i = JSON.stringify(i)), !1 !== t.save && "undefined" != typeof Storage && localStorage.setItem("pq-grid" + (o || ""), i)),
                i
            );
        }),
        (e.getState = function () {
            if ("undefined" != typeof Storage) return localStorage.getItem("pq-grid" + (this.element[0].id || ""));
        }),
        (e.loadState = function (t) {
            var e = this,
                n = m.widget.extend,
                i = (t = t || {}).state || e.getState();
            if (!i) return !1;
            for (var r, o, a, l = (i = "string" == typeof i ? JSON.parse(i) : i).colModel, s = [], d = [], c = e.options, u = c[_b(313)], h = 1 < e.depth, f = (h ? e : c).colModel, p = 0, g = l.length; p < g; p++)
                (s[(a = (r = l[p]).dataIndx)] = r), (d[a] = p);
            for (
                h ||
                    f.sort(function (t, e) {
                        return d[t.dataIndx] - d[e.dataIndx];
                    }),
                    p = 0,
                    g = f.length;
                p < g;
                p++
            )
                (r = s[(a = (o = f[p]).dataIndx)]) && e._saveState(r, o, u);
            return (
                e.iCols.init(),
                n(c.sortModel, i.sortModel),
                n(c.pageModel, i.pageModel),
                e.Group().option(i.groupModel, !1),
                e.Tree().option(i.treeModel, !1),
                (h = { freezeRows: i.freezeRows, freezeCols: i.freezeCols }),
                isNaN(+c.height) || isNaN(+i.height) || (h.height = i.height),
                isNaN(+c.width) || isNaN(+i.width) || (h.width = i.width),
                e.option(h),
                !1 !== t.refresh && e[_b(118)](),
                !0
            );
        }),
        (e[_b(292)] = function () {
            var t,
                e,
                n,
                i,
                r = this,
                o = r.options,
                a = o.toolbar;
            r._toolbar && (t = r._toolbar).destroy(),
                a &&
                    ((i = a.cls || ""),
                    (e = a.style || ""),
                    (n = a.attr || ""),
                    (a = a.items),
                    (i = m("<div class='" + i + "' style='" + e + "' " + n + " ></div>")),
                    t ? t.widget()[_b(314)](i) : r.$top.append(i),
                    (t = pq.toolbar(i, { items: a, gridInstance: r, bootstrap: o.bootstrap })),
                    o[_b(315)] || i.css("display", "none"),
                    (r._toolbar = t));
        }),
        (e.filter = function (t) {
            return this[_b(159)].filter(t);
        }),
        (e.Checkbox = function (t) {
            return this.iCheckBox[t];
        }),
        (e[_b(316)] = function () {
            this[_b(115)].refreshHS();
        }),
        (e[_b(317)] = function () {
            this.iRenderSum.refreshHS();
        }),
        (e[_b(318)] = function (t) {
            var t = this.normalize(t),
                e = t.colIndx,
                t = t.column,
                n = this[_b(115)],
                i = n.rows - 1;
            this.options[_b(157)].header && (n[_b(171)](i, e, {}, t), n[_b(270)](t, e, i));
        }),
        (e.pageData = function () {
            return this.pdata;
        }),
        (e.getData = function (t) {
            var e = (t = t || {}).dataIndx,
                n = e ? e.length : 0,
                t = t.data,
                i = !n,
                r = this.columns,
                o = this.options.dataModel,
                a = o[_b(319)] || o.data || [],
                o = o.dataUF || [],
                l = [];
            if (!n) return o.length ? a.concat(o) : a;
            t ? p(t, e, l) : (p(a, e, l), p(o, e, l));
            for (
                var s = [],
                    n = e.reduce(function (t, e) {
                        var n = r[e];
                        return n && t.push({ dataIndx: e, dir: "up", dataType: n.dataType, sortType: n.sortType }), t;
                    }, []),
                    d = {},
                    c = 0,
                    u = l.length;
                c < u;
                c++
            ) {
                var h = l[c],
                    f = JSON.stringify(h);
                d[f] || (s.push(h), (d[f] = 1));
            }
            return (s = this.iSort[_b(320)](n, s, i));
        }),
        (e[_b(321)] = function (t, i) {
            var e = t[0];
            return (
                m[_b(43)](e)
                    ? (e = Object.keys(e))[0] != i &&
                      1 == e.length &&
                      (t = t.map(function (t) {
                          var e,
                              n = {};
                          for (e in t) (n[i] = e), (n.pq_label = t[e]);
                          return n;
                      }))
                    : (t = t.map(function (t) {
                          var e = {};
                          return (e[i] = t), e;
                      })),
                t
            );
        }),
        (e[_b(322)] = function (t, e, n) {
            var i,
                r = this,
                o = r.options[_b(157)],
                a = o.newDI.slice(),
                e = e ? [e, t] : [t],
                t = a.indexOf(t);
            return (
                "AND" == o.mode &&
                    a.length &&
                    "remote" != o.type &&
                    (0 <= t && a.splice(t, a.length),
                    a.length &&
                        ((o = a.map(function (t) {
                            var e = r.getColumn({ dataIndx: t }).filter;
                            return { dataIndx: t, crules: e.crules || [e], mode: e.mode };
                        })),
                        (i = r.filter({ data: r.getData(), mode: "AND", rules: o })))),
                (e = e.concat(n || [])),
                r.getData({ data: i, dataIndx: e })
            );
        }),
        (e[_b(323)] = function (t, n, e) {
            var i;
            return null == e
                ? t.filter(function (t) {
                      var e = t[n];
                      return (null != e && "" !== e) || (i ? void 0 : ((i = !0), !(t[n] = "")));
                  })
                : t.filter(function (t) {
                      t = t[n];
                      return null != t && "" !== t;
                  });
        }),
        (e.get_p_data = function () {
            var t,
                e = this.options,
                n = e.pageModel,
                i = n.type,
                e = e.dataModel.data,
                r = this.pdata,
                o = [];
            return i
                ? ((n = n.rPP), (t = this.riOffset || 0), !r.length && e.length && (r = e.slice(t, t + n)), (o = (i = "remote" == i) ? new Array(t) : e.slice(0, t)), (i = i ? [] : e.slice(t + n)), o.concat(r, i))
                : r.length
                ? r
                : e;
        }),
        (e[_b(147)] = function (t) {
            var e = this,
                n = e.options,
                i = !(t = t || {}).data,
                r = t.source,
                o = t.sort,
                a = [],
                l = n[_b(157)],
                s = n.dataModel,
                n = n.sortModel;
            if (
                (e.iRefresh.addRT(t.data),
                !1 != i && !(e.pdata = []) !== t.trigger && e._trigger("dataAvailable", t.evt, { source: r }),
                (a = (l && l.on && "local" == l.type && 0 != t.filter ? e[_b(159)][_b(324)](t) : s).data),
                "local" == n.type && !1 !== o && (i ? e.sort({ refresh: !1 }) : (a = e.iSort[_b(325)](a, !0))),
                !1 == i)
            )
                return a;
            e[_b(17)](t);
        }),
        (e.reset = function (t) {
            var e = this,
                n = (t = t || {}).sort,
                i = e.options,
                r = !1 !== t.refresh,
                o = m.extend,
                a = t.filter,
                t = t.group;
            (n || a || t) &&
                (n && o(i.sortModel, !0 === n ? { sorter: [] } : n),
                a && !r && this[_b(159)][_b(326)](e.colModel),
                t && e[_b(327)](!0 === t ? { dataIndx: [] } : t, !1),
                r && (a ? (e.filter({ oper: "replace", rules: [] }), e[_b(316)]()) : n ? e.sort() : e[_b(17)]()));
        }),
        (e._trigger = n._trigger),
        (e.on = n.on),
        (e.one = n.one),
        (e.off = n.off),
        (e.pager = function () {
            var t;
            return (this.pageI = this.pageI || ((t = this.widget().find(".pq-pager")).length ? t.pqPager("instance") : null)), this.pageI;
        }),
        (e.toolbar = function () {
            return this._toolbar.element;
        }),
        (e.Columns = function () {
            return this.iCols;
        });
})