<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <title>Excel File Upload</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
            <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('index')); ?>">
            <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
                <div class="form-group">
                    <label for="exampleFormControlFile1">Excel File Upload</label>
                    <input type="file" class="form-control-file" id="exampleFormControlFile1" name="file">
                </div>
                <button type="submit" class="btn btn-primary">Upload</button>
            </form>
        </div>
    </body>
</html><?php /**PATH C:\laragon\www\newtest\resources\views/newfile.blade.php ENDPATH**/ ?>