<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Class\SimpleXLSX;

class fileUploadController extends Controller
{
    public function index(Request $request)
    {
        if (isset($request->file)) {
            // if ( $xlsx = SimpleXLSX::parse( $request->file ) ) {
            //     // echo '<h2>Parsing Result</h2>';
            //     // echo '<table border="1" cellpadding="3" style="border-collapse: collapse">';
            //     // $dim = $xlsx->dimension();
            //     // $cols = $dim[0];
            //     // foreach ( $xlsx->rows() as $k => $r ) {
            //     //     echo '<tr>';
            //     //     for ( $i = 0; $i < $cols; $i ++ ) {
            //     //         echo '<td>' . ( isset( $r[ $i ] ) ? $r[ $i ] : 'colspan="'.$r[ $i ].'"' ) . '</td>';
            //     //     }
            //     //     echo '</tr>';
            //     // }
            //     // echo '</table>';
            //     echo $xlsx->toHTML();
            // } else {
            //     echo SimpleXLSX::parseError();
            // }
            $file = $request->file('file');
            $destinationPath = 'Jspreadsheet/uploadexcel';
            $file->move($destinationPath,$file->getClientOriginalName());
        }

        return redirect()->back();
    }
}
